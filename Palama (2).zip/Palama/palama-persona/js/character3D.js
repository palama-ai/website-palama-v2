let engine, scene, camera, character;

// دالة لتحميل النموذج
async function loadModel() {
    console.log('Starting to load model...');
    
    try {
        // استخدام المسار المطلق الكامل للملف
        const rootUrl = "/Rin/";
        const fileName = "Rin.glb";
        console.log('Loading model from:', rootUrl + fileName);
        
        // إنشاء مشهد مؤقت للتحميل
        const result = await BABYLON.SceneLoader.ImportMeshAsync(
            null,
            rootUrl,
            fileName,
            scene
        );

        console.log('Model loaded successfully!', result);
        
        if (result.meshes.length > 0) {
            // الحصول على النموذج
            character = result.meshes[0];
            
            // تعديل حجم وموضع النموذج
            character.scaling = new BABYLON.Vector3(0.5, 0.5, 0.5);
            character.position = new BABYLON.Vector3(0, -0.5, 0);
            character.rotation = new BABYLON.Vector3(0, Math.PI, 0);

            // إضافة حركة دوران تلقائية
            scene.registerBeforeRender(() => {
                character.rotation.y += 0.005;
            });
        } else {
            throw new Error('No meshes were loaded');
        }

    } catch (error) {
        console.error('Error loading model:', error);
        console.error('Current location:', window.location.href);
        
        // إنشاء شكل مؤقت في حالة فشل التحميل
        character = BABYLON.MeshBuilder.CreateBox("box", {
            size: 1
        }, scene);
        
        // مادة شفافة خضراء
        const material = new BABYLON.StandardMaterial("boxMaterial", scene);
        material.diffuseColor = new BABYLON.Color3(0, 1, 0);
        material.alpha = 0.8;
        character.material = material;

        // إضافة حركة دوران للشكل المؤقت
        scene.registerBeforeRender(() => {
            character.rotation.y += 0.005;
        });
    }
}

function createScene() {
    // إنشاء المحرك والمشهد
    const canvas = document.getElementById('character-container');
    if (!canvas) {
        console.error('Canvas element not found!');
        return null;
    }

    // تهيئة المحرك
    engine = new BABYLON.Engine(canvas, true, { 
        preserveDrawingBuffer: true, 
        stencil: true,
        adaptToDeviceRatio: true,
        antialias: true
    });

    // إنشاء المشهد
    scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color4(0, 0, 0, 0);

    // إنشاء الكاميرا
    camera = new BABYLON.ArcRotateCamera(
        "camera",
        0,
        Math.PI / 2,
        5,
        BABYLON.Vector3.Zero(),
        scene
    );
    camera.attachControl(canvas, true);
    camera.lowerRadiusLimit = 3;
    camera.upperRadiusLimit = 10;
    camera.wheelPrecision = 50;
    camera.pinchPrecision = 50;
    camera.useBouncingBehavior = true;

    // تعطيل التكبير/التصغير
    camera.useMouseWheel = false;

    // إضافة الإضاءة
    const light1 = new BABYLON.HemisphericLight(
        "light1",
        new BABYLON.Vector3(0, 1, 0),
        scene
    );
    light1.intensity = 0.7;

    const light2 = new BABYLON.DirectionalLight(
        "light2",
        new BABYLON.Vector3(-1, -1, -1),
        scene
    );
    light2.intensity = 0.5;

    // إضافة معالج الأخطاء للمشهد
    scene.onError = function(scene, error) {
        console.error('Scene error:', error);
    };

    // تحميل النموذج
    loadModel().catch(error => {
        console.error('Failed to load model:', error);
    });

    return scene;
}

// التعامل مع تغيير حجم النافذة
window.addEventListener('resize', function() {
    if (engine) {
        engine.resize();
    }
});

// بدء التشغيل عند تحميل الصفحة
window.addEventListener('DOMContentLoaded', function() {
    const scene = createScene();
    if (scene) {
        engine.runRenderLoop(function() {
            scene.render();
        });
    }
});