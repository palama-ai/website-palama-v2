document.addEventListener('DOMContentLoaded', () => {
    const micButton = document.querySelector('.mic-button');
    const closeButton = document.querySelector('.control-btn:has(img[alt="Close"])');
    const chatButton = document.querySelector('.control-btn:has(img[alt="Chat"])');
    const profileButton = document.querySelector('.control-btn:has(img[alt="Profile"])');

    let isListening = false;

    micButton.addEventListener('click', () => {
        isListening = !isListening;
        micButton.style.backgroundColor = isListening ? '#8A2BE2' : '#fff';
        micButton.querySelector('img').style.filter = isListening ? 'invert(1)' : 'none';
    });

    closeButton.addEventListener('click', () => {
        // Handle close action
        console.log('Close clicked');
    });

    chatButton.addEventListener('click', () => {
        // Handle chat action
        console.log('Chat clicked');
    });

    profileButton.addEventListener('click', () => {
        // Handle profile action
        console.log('Profile clicked');
    });
});
