const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

// تمكين CORS لجميع الطلبات
app.use(cors());

// تعيين المجلد الحالي كمجلد ثابت
app.use(express.static(__dirname));

const port = 3000;
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
