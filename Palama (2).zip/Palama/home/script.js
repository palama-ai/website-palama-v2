// Navigation item click handler
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');
        
        // Add ripple effect
        const ripple = document.createElement('div');
        ripple.classList.add('ripple');
        item.appendChild(ripple);
        setTimeout(() => ripple.remove(), 1000);
    });
});

// Add this at the beginning of your script.js file
const userProfile = document.querySelector('.user-profile');
const profilePopup = document.querySelector('.profile-popup');

userProfile.addEventListener('click', (e) => {
    e.stopPropagation();
    profilePopup.classList.toggle('show');
});

// Close popup when clicking outside
document.addEventListener('click', (e) => {
    if (!userProfile.contains(e.target)) {
        profilePopup.classList.remove('show');
    }
});

// Prevent popup from closing when clicking inside it
profilePopup.addEventListener('click', (e) => {
    e.stopPropagation();
});

// Handle profile popup sign in click
const signInOption = document.querySelector('.popup-item:first-child');
const signInModal = document.getElementById('signInModal');

signInOption.addEventListener('click', () => {
    profilePopup.classList.remove('show');
    showModal(signInModal);
});

// Handle profile popup sign up click
const signUpOption = document.querySelector('.popup-item:last-child');
const signUpModal = document.getElementById('signUpModal');

signUpOption.addEventListener('click', () => {
    profilePopup.classList.remove('show');
    showModal(signUpModal);
});

// Sign In Modal Functionality
const signInButton = document.querySelector('.popup-item:first-child');
const closeModal = document.querySelector('.close-modal');
const loginForm = document.querySelector('.login-form');

signInButton.addEventListener('click', () => {
    profilePopup.classList.remove('show');
    showModal(signInModal);
});

closeModal.addEventListener('click', () => {
    hideModal(signInModal);
});

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target === signInModal) {
        hideModal(signInModal);
    }
});

// Password visibility toggle
const togglePassword = document.querySelector('.toggle-password');
const passwordInput = togglePassword.previousElementSibling;

togglePassword.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePassword.classList.toggle('fa-eye');
    togglePassword.classList.toggle('fa-eye-slash');
});

// Form submission animation
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const loginButton = loginForm.querySelector('.login-button');
    loginButton.style.width = '50px';
    loginButton.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>';
    
    // Simulate login delay
    setTimeout(() => {
        loginButton.innerHTML = '<i class="fas fa-check"></i>';
        setTimeout(() => {
            loginButton.style.width = '100%';
            loginButton.innerHTML = '<span>Sign In</span><i class="fas fa-arrow-right"></i>';
        }, 1000);
    }, 2000);
});

// Handle form submission
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    // Add your login logic here
    console.log('Login submitted');
});

// Sign Up Modal
const signUpLink = document.querySelector('.signup-link');
const signInLink = document.querySelector('.signin-link');

// Function to smoothly show modal
function showModal(modal) {
    modal.style.display = 'flex';
    // Trigger reflow
    modal.offsetHeight;
    modal.classList.add('show');
}

// Function to smoothly hide modal
function hideModal(modal) {
    modal.classList.remove('show');
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300); // Match transition duration
}

// Function to switch between modals
function switchModals(fromModal, toModal) {
    hideModal(fromModal);
    setTimeout(() => {
        showModal(toModal);
    }, 300); // Match transition duration
}

// Get all sign up links
document.querySelectorAll('.signup-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        switchModals(signInModal, signUpModal);
    });
});

// Get all sign in links
document.querySelectorAll('.signin-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        switchModals(signUpModal, signInModal);
    });
});

// Close modals when clicking outside
[signInModal, signUpModal].forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            hideModal(modal);
        }
    });
});

// Close modals with close button
document.querySelectorAll('.close-modal').forEach(button => {
    button.addEventListener('click', () => {
        const modal = button.closest('.modal');
        hideModal(modal);
    });
});

// Open Sign Up Modal
signUpLink.addEventListener('click', (e) => {
    e.preventDefault();
    hideModal(signInModal);
    showModal(signUpModal);
});

// Switch back to Sign In
signInLink.addEventListener('click', (e) => {
    e.preventDefault();
    hideModal(signUpModal);
    showModal(signInModal);
});

// Close Sign Up Modal when clicking outside
signUpModal.addEventListener('click', (e) => {
    if (e.target === signUpModal) {
        hideModal(signUpModal);
    }
});

// Close Sign Up Modal with close button
signUpModal.querySelector('.close-modal').addEventListener('click', () => {
    hideModal(signUpModal);
});

// Password visibility toggle for sign up form
const togglePasswordButtons = signUpModal.querySelectorAll('.toggle-password');
togglePasswordButtons.forEach(button => {
    button.addEventListener('click', () => {
        const input = button.previousElementSibling;
        const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        button.classList.toggle('fa-eye');
        button.classList.toggle('fa-eye-slash');
    });
});

// Handle sign up form submission
const signUpForm = document.querySelector('.signup-form');
signUpForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Get form fields
    const username = signUpForm.querySelector('input[type="text"]').value;
    const email = signUpForm.querySelector('input[type="email"]').value;
    const password = signUpForm.querySelector('input[type="password"]').value;
    const confirmPassword = signUpForm.querySelectorAll('input[type="password"]')[1].value;
    const termsAccepted = signUpForm.querySelector('input[type="checkbox"]').checked;
    
    // Validate form
    if (!username || !email || !password || !confirmPassword) {
        alert('Please fill in all required fields');
        return;
    }
    
    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }
    
    if (!termsAccepted) {
        alert('Please accept the Terms and Conditions');
        return;
    }
    
    // Show loading animation
    const signUpButton = signUpForm.querySelector('.signup-button');
    const originalButtonContent = signUpButton.innerHTML;
    signUpButton.style.width = '50px';
    signUpButton.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>';
    
    // Simulate API call
    setTimeout(() => {
        signUpButton.innerHTML = '<i class="fas fa-check"></i>';
        
        // Reset form and close modal after success
        setTimeout(() => {
            signUpForm.reset();
            signUpModal.style.display = 'none';
            signUpModal.classList.remove('show');
            signUpButton.style.width = '';
            signUpButton.innerHTML = originalButtonContent;
        }, 1000);
    }, 2000);
});

// Social buttons hover effect
document.querySelectorAll('.social-btn').forEach(btn => {
    btn.addEventListener('mouseover', () => {
        btn.style.transform = 'translateY(-2px)';
    });
    
    btn.addEventListener('mouseout', () => {
        btn.style.transform = 'translateY(0)';
    });
});

// Tool cards interaction
document.querySelectorAll('.tool-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        card.style.setProperty('--mouse-x', `${x}px`);
        card.style.setProperty('--mouse-y', `${y}px`);
    });
});

// Search animation
const searchInput = document.querySelector('.search-input');
const searchButton = document.querySelector('.search-button');

searchInput.addEventListener('focus', () => {
    searchButton.style.transform = 'scale(1.1)';
});

searchInput.addEventListener('blur', () => {
    searchButton.style.transform = 'scale(1)';
});

// Persona button effect
const personaButton = document.querySelector('.persona-button button');
personaButton.addEventListener('mousemove', (e) => {
    const rect = personaButton.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const angleX = (y - centerY) / centerY * 10;
    const angleY = (centerX - x) / centerX * 10;
    
    personaButton.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) scale(1.05)`;
});

personaButton.addEventListener('mouseleave', () => {
    personaButton.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
});

// Add ripple effect to buttons
function createRipple(event) {
    const button = event.currentTarget;
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    
    const diameter = Math.max(rect.width, rect.height);
    const radius = diameter / 2;
    
    ripple.style.width = ripple.style.height = `${diameter}px`;
    ripple.style.left = `${event.clientX - rect.left - radius}px`;
    ripple.style.top = `${event.clientY - rect.top - radius}px`;
    ripple.classList.add('button-ripple');
    
    const rippleContainer = button.getElementsByClassName('button-ripple')[0];
    if (rippleContainer) {
        rippleContainer.remove();
    }
    
    button.appendChild(ripple);
}

// Add ripple effect to all buttons
document.querySelectorAll('.login-button, .signup-button, .social-btn').forEach(button => {
    button.addEventListener('click', createRipple);
});

// Form validation with animations
function validateInput(input) {
    const inputGroup = input.closest('.input-group');
    const value = input.value.trim();
    
    // Remove previous states
    inputGroup.classList.remove('error', 'success');
    
    if (value === '') {
        inputGroup.classList.add('error');
        return false;
    }
    
    if (input.type === 'email') {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            inputGroup.classList.add('error');
            return false;
        }
    }
    
    if (input.type === 'password') {
        if (value.length < 6) {
            inputGroup.classList.add('error');
            return false;
        }
    }
    
    inputGroup.classList.add('success');
    return true;
}

// Add validation to all inputs
document.querySelectorAll('.input-group input').forEach(input => {
    input.addEventListener('blur', () => validateInput(input));
});

// Password strength indicator
function updatePasswordStrength(input) {
    const strength = {
        0: "Very Weak",
        1: "Weak",
        2: "Medium",
        3: "Strong",
        4: "Very Strong"
    };
    
    let score = 0;
    const password = input.value;
    
    // Add points for length
    if (password.length > 6) score++;
    if (password.length > 10) score++;
    
    // Add point for numbers
    if (/\d/.test(password)) score++;
    
    // Add point for special characters
    if (/[!@#$%^&*]/.test(password)) score++;
    
    const strengthIndicator = input.parentElement.querySelector('.password-strength');
    if (strengthIndicator) {
        strengthIndicator.textContent = strength[score];
        strengthIndicator.className = 'password-strength ' + strength[score].toLowerCase().replace(' ', '-');
    }
}

// Add password strength indicator to password fields
document.querySelectorAll('input[type="password"]').forEach(input => {
    const strengthIndicator = document.createElement('div');
    strengthIndicator.classList.add('password-strength');
    input.parentElement.appendChild(strengthIndicator);
    
    input.addEventListener('input', () => updatePasswordStrength(input));
});

// Add floating label animation
document.querySelectorAll('.input-group input').forEach(input => {
    const label = document.createElement('label');
    label.textContent = input.placeholder;
    input.parentElement.appendChild(label);
    input.setAttribute('placeholder', ' ');
});
