// Custom Cursor functionality
document.addEventListener('DOMContentLoaded', function() {
    // Create cursor elements if they don't exist
    if (!document.querySelector('.custom-cursor')) {
        const cursor = document.createElement('div');
        cursor.className = 'custom-cursor';
        document.body.appendChild(cursor);

        const cursorDot = document.createElement('div');
        cursorDot.className = 'custom-cursor-dot';
        document.body.appendChild(cursorDot);
    }

    const cursor = document.querySelector('.custom-cursor');
    const cursorDot = document.querySelector('.custom-cursor-dot');
    let cursorVisible = true;
    let cursorEnlarged = false;

    // Mouse movement
    const onMouseMove = (e) => {
        const mouseX = e.clientX;
        const mouseY = e.clientY;
        
        cursor.style.left = `${mouseX}px`;
        cursor.style.top = `${mouseY}px`;
        
        cursorDot.style.left = `${mouseX}px`;
        cursorDot.style.top = `${mouseY}px`;

        // Create trail effect
        const trail = document.createElement('div');
        trail.className = 'cursor-trail';
        trail.style.left = `${mouseX}px`;
        trail.style.top = `${mouseY}px`;
        document.body.appendChild(trail);

        // Remove trail after animation
        setTimeout(() => {
            trail.remove();
        }, 500);
    };

    document.addEventListener('mousemove', onMouseMove);

    // Cursor hover effect
    const onMouseEnter = () => {
        cursor.classList.add('hover');
        if (!cursorEnlarged) {
            cursorEnlarged = true;
        }
    };

    const onMouseLeave = () => {
        cursor.classList.remove('hover');
        if (cursorEnlarged) {
            cursorEnlarged = false;
        }
    };

    // Add hover effect to interactive elements
    document.querySelectorAll([
        'a', 
        'button', 
        'input[type="button"]',
        'input[type="submit"]',
        'input[type="reset"]',
        '.project-card',
        '.filter-btn',
        '.nav-link',
        '.btn'
    ].join(',')).forEach(element => {
        element.addEventListener('mouseenter', onMouseEnter);
        element.addEventListener('mouseleave', onMouseLeave);
    });

    // Hide/show cursor
    document.addEventListener('mouseenter', () => {
        cursor.style.opacity = 1;
        cursorDot.style.opacity = 1;
        cursorVisible = true;
    });

    document.addEventListener('mouseleave', () => {
        cursor.style.opacity = 0;
        cursorDot.style.opacity = 0;
        cursorVisible = false;
    });
});
