from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.core.config import settings
from app.api.routes import api_router
from app.db.session import engine
from app.db.init_db import init_db

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Setup - initialize database, create first admin if not exists
    await init_db()
    yield
    # Cleanup - close connections, etc.

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="AI-Powered Chatbot Management Platform API",
    version="1.0.0",
    lifespan=lifespan,
)

# Set up CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all API routes
app.include_router(api_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
