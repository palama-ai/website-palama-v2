import logging
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import engine, async_session
from app.db.base import Base
from app.core.config import settings
from app.crud.crud_user import user
from app.schemas.user import UserCreate
from app.core.security import get_password_hash

logger = logging.getLogger(__name__)


async def init_db() -> None:
    """Initialize the database by creating tables and setting up initial data."""
    async with engine.begin() as conn:
        # Create all tables
        await conn.run_sync(Base.metadata.create_all)
    
    # Create first superuser if it doesn't exist
    async with async_session() as db:
        await create_first_superuser(db)


async def create_first_superuser(db: AsyncSession) -> None:
    """Create the first superuser if it doesn't exist."""
    try:
        superuser = await user.get_by_email(db, email=settings.FIRST_SUPERUSER_EMAIL)
        if not superuser:
            user_in = UserCreate(
                email=settings.FIRST_SUPERUSER_EMAIL,
                password=settings.FIRST_SUPERUSER_PASSWORD,
                is_superuser=True,
                full_name="Initial Admin",
            )
            await user.create(db, obj_in=user_in)
            logger.info("Initial superuser created")
        else:
            logger.info("Superuser already exists")
    except Exception as e:
        logger.error(f"Error creating superuser: {e}")
