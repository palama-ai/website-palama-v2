from sqlalchemy import Boolean, Column, Integer, String, ForeignKey, DateTime, Float, Enum
from sqlalchemy.orm import relationship
import enum
from datetime import datetime

from app.db.base_class import Base


class PaymentStatus(enum.Enum):
    PENDING = "pending"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    REFUNDED = "refunded"


class PaymentMethod(enum.Enum):
    CARD = "card"
    BANK_TRANSFER = "bank_transfer"
    PAYPAL = "paypal"


class Payment(Base):
    id = Column(Integer, primary_key=True, index=True)
    amount = Column(Float, nullable=False)
    currency = Column(String, default="USD")
    status = Column(Enum(PaymentStatus), default=PaymentStatus.PENDING)
    method = Column(Enum(PaymentMethod), nullable=True)
    stripe_payment_id = Column(String, unique=True, nullable=True)
    payment_date = Column(DateTime, default=datetime.utcnow)
    description = Column(String, nullable=True)
    
    # Foreign keys
    user_id = Column(Integer, ForeignKey("user.id"), nullable=False)
    subscription_id = Column(Integer, ForeignKey("subscription.id"), nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="payments")
    subscription = relationship("Subscription")
