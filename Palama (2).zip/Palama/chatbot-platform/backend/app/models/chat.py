from sqlalchemy import Boolean, Column, Integer, String, ForeignKey, DateTime, Text, Enum
from sqlalchemy.orm import relationship
import enum

from app.db.base_class import Base


class AIModel(enum.Enum):
    OPENAI = "openai"
    OLLAMA = "ollama"
    DEEPSEEK = "deepseek"


class Role(enum.Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class Chat(Base):
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False, default="New Chat")
    is_archived = Column(Boolean, default=False)
    ai_model = Column(Enum(AIModel), default=AIModel.OPENAI)
    
    # Foreign keys
    user_id = Column(Integer, ForeignKey("user.id"), nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="chats")
    messages = relationship("Message", back_populates="chat", cascade="all, delete-orphan")


class Message(Base):
    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)
    role = Column(Enum(Role), nullable=False)
    tokens_used = Column(Integer, default=0)
    
    # Foreign keys
    chat_id = Column(Integer, ForeignKey("chat.id"), nullable=False)
    
    # Relationships
    chat = relationship("Chat", back_populates="messages")
