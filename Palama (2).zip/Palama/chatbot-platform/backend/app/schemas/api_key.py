from typing import Optional
from pydantic import BaseModel
from datetime import datetime


# Shared properties
class APIKeyBase(BaseModel):
    name: str
    is_active: Optional[bool] = True
    expires_at: Optional[datetime] = None


# Properties to receive via API on creation
class APIKeyCreate(APIKeyBase):
    user_id: int


# Properties to receive via API on update
class APIKeyUpdate(APIKeyBase):
    pass


# Properties shared by models stored in DB
class APIKeyInDBBase(APIKeyBase):
    id: int
    key: str
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    last_used_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# Additional properties to return via API
class APIKey(APIKeyInDBBase):
    pass


# Additional information for API key creation response
class APIKeyCreateResponse(BaseModel):
    api_key: APIKey
    raw_key: str  # The actual API key to be shown only once
